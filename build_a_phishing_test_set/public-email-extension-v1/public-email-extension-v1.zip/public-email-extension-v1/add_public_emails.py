#!/usr/bin/env python3
"""Fetch, sanitize, group and add source-labeled public emails; evaluate frozen v1 baselines.
Run beside dataset.synthetic.jsonl and synthetic_schema.json: python3 add_public_emails.py
No email is sent, link followed, attachment saved or response action executed.
"""
import csv, hashlib, io, json, mailbox, re, tempfile, html, shutil, zipfile
from pathlib import Path
from email import policy
from email.parser import BytesParser
from html.parser import HTMLParser
from datetime import datetime, timezone
import requests
import numpy as np
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

ROOT=Path(__file__).resolve().parent
SYN=ROOT/'dataset.synthetic.jsonl'
SEED=172289201
MAX_BYTES=2*1024*1024
N_PER_CLASS=50
# Conservative text-only review: these corpus entries have insufficient phishing
# evidence once attachments/transport headers are removed, or are generic fraud.
NAZARIO_EXCLUSIONS={
 12:'Bank eStatement; attack evidence may be in an omitted attachment.',
 17:'Bank eStatement; text alone does not establish phishing.',
 29:'USAA notice with no retained malicious destination or explicit secret request.',
 33:'Sign-in notice; text alone lacks the original action destination.',
 40:'Money-transfer investment solicitation; generic advance-fee fraud, not a phishing-only positive.',
 45:'DocuSign notice; text alone lacks the original action destination.',
 69:'Password notice; text alone lacks the original action destination.',
 87:'Smarsh encryption notice; apparent legitimate host, insufficient text-only attack evidence.',
 76:'Smarsh encryption notice; apparent legitimate host, insufficient text-only attack evidence.',
 19:'Bank eStatement; attack evidence may be in an omitted attachment.'}
EXPECTED_SOURCE_SHA256={'nazario':'636707cff42245d1482e4ae8a2c03369717a5e06bf9d1a0f4ec5dcd846661cee','enron_prefix':'6e00120f4440ecb3992dea24eceeb49f2a0feaf20af6283ddd61884b43718764'}

class VisibleHTML(HTMLParser):
 def __init__(self): super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'):self.skip+=1
  if tag=='a' and not self.skip:
   href=dict(attrs).get('href','')
   if href:self.parts.append(' '+href+' ')
 def handle_endtag(self,tag):
  if tag in ('script','style'):self.skip=max(0,self.skip-1)
  if tag in ('p','br','div','tr'):self.parts.append('\n')
 def handle_data(self,data):
  if not self.skip:self.parts.append(data)

def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()

def download(url,limit=None):
 with requests.get(url,stream=True,timeout=(20,90),headers={'Range':f'bytes=0-{limit-1}'} if limit else {}) as r:
  r.raise_for_status();buf=bytearray()
  for c in r.iter_content(65536):
   buf.extend(c)
   if limit and len(buf)>=limit:break
  return bytes(buf[:limit] if limit else buf)

def clean(subject,body):
 text='Subject: '+str(subject)+'\n'+html.unescape(body)
 text=re.sub(r'(?i)\[\s*spam\s*\]','',text)
 text=re.sub(r'<[^>]+>',lambda m:' '+' '.join(re.findall(r'https?://[^\s\"<>]+',m[0]))+' ',text) # preserve destinations in malformed residual HTML
 text=re.sub(r'(?im)^\s*(?:from|to|cc|bcc|reply-to|return-path|message-id|received|x-[\w-]+)\s*:.*$','[HEADER REMOVED]',text)
 # Handles both ordinary addresses and spaced/tokenized Enron addresses.
 text=re.sub(r'\b[\w.+-]+(?:\s*\.\s*[\w+-]+)*\s*@\s*[\w-]+(?:\s*\.\s*[\w-]+)+','[EMAIL REDACTED]',text)
 text=re.sub(r'(?<!\w)(?:\+?\d[\d(). -]{7,}\d)(?!\w)','[NUMBER REDACTED]',text)
 text=re.sub(r'(?i)https?://',lambda m:'hxxps://' if m[0].lower().startswith('https') else 'hxxp://',text)
 text=re.sub(r'(?i)\bwww\.', 'www[.]',text)
 text=re.sub(r'[^\S\n]+',' ',text)
 text=re.sub(r'\n{3,}','\n\n',text).strip()
 return text

def norm(text):
 text=re.sub(r'(?i)(?:hxxps?|https?)://\S+',' URL ',text.lower())
 text=re.sub(r'\d+',' N ',text)
 return ' '.join(re.findall(r'[a-z]+',text))

def mail_body(msg):
 leaves=[p for p in msg.walk() if not p.is_multipart() and p.get_content_disposition()!='attachment']
 for typ in ['text/plain','text/html']:
  parts=[]
  for p in leaves:
   if p.get_content_type()!=typ:continue
   raw=p.get_payload(decode=True)
   if raw is None:continue
   charset=p.get_content_charset() or 'utf-8'
   try:t=raw.decode(charset,errors='replace')
   except LookupError:t=raw.decode('utf-8',errors='replace')
   if typ=='text/html':
    parser=VisibleHTML();parser.feed(t);t=' '.join(parser.parts)
   parts.append(t)
  if parts:return '\n'.join(parts)
 return ''

def writecsv(path,rows):
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def scores(y,p):
 tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
 return dict(n=len(y),accuracy=float(accuracy_score(y,p)),precision=float(precision_score(y,p,zero_division=0)),recall=float(recall_score(y,p,zero_division=0)),f1=float(f1_score(y,p,zero_division=0)),false_positive_rate=float(fp/(fp+tn)),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp))

def main():
 synth=[json.loads(l) for l in SYN.read_text().splitlines()]
 mbox_url='https://monkey.org/~jose/phishing/phishing-2021'
 enron_url='https://zenodo.org/api/records/8339691/files/Enron.csv/content'
 raw_mail=download(mbox_url);raw_enron=download(enron_url,MAX_BYTES)
 assert sha(raw_mail)==EXPECTED_SOURCE_SHA256['nazario'], 'Nazario changed: review source before rebuilding.'
 assert sha(raw_enron)==EXPECTED_SOURCE_SHA256['enron_prefix'], 'Enron prefix changed: review source before rebuilding.'
 manifest=dict(retrieved_utc=datetime.now(timezone.utc).isoformat(),selection='SHA256-ranked, one representative per inferred normalized/near-duplicate component, 50 per class; no model-dependent selection.',sources=[dict(name='Nazario 2021',url=mbox_url,sha256=sha(raw_mail),bytes=len(raw_mail),license='CC BY 4.0 (original host)',license_evidence='https://monkey.org/~jose/phishing/README.txt'),dict(name='Enron curated CSV',url=enron_url,sha256_prefix=sha(raw_enron),prefix_bytes=len(raw_enron),license='CC BY 4.0 (curator declaration; underlying email rights not independently cleared)',license_evidence='https://zenodo.org/api/records/8339691')],python_dependencies=dict(numpy=np.__version__,sklearn=sklearn.__version__,requests=requests.__version__))
 candidates=[]
 with tempfile.TemporaryDirectory() as td:
  path=Path(td)/'source.mbox';path.write_bytes(raw_mail)
  box=mailbox.mbox(str(path),factory=lambda f:BytesParser(policy=policy.default).parse(f))
  for i,msg in enumerate(box):
   subject=str(msg.get('Subject',''));sender=str(msg.get('From',''))
   if 'folder internal data' in subject.lower() or 'mailer-daemon' in sender.lower() or i in NAZARIO_EXCLUSIONS:continue
   body=mail_body(msg);text=clean(subject,body)
   if 150<=len(text)<=16000:
    candidates.append(dict(source='Nazario_2021',source_row=i,source_label='phishing_corpus_membership',label=1,text=text,raw_sha256=sha(msg.as_bytes())))
  box.close()
 rd=list(csv.DictReader(io.StringIO(raw_enron.decode('utf-8-sig','replace'))))
 for i,row in enumerate(rd[:-1]): # truncated final CSV row is never eligible
  if row.get('label')!='0':continue # NEVER treat Enron spam=1 as phishing
  subject=row.get('subject') or '';body=row.get('body') or '';text=clean(subject,body)
  if 150<=len(text)<=16000:
   candidates.append(dict(source='Enron_curated_label0',source_row=i,source_label='0_nonspam',label=0,text=text,raw_sha256=sha(json.dumps(row,sort_keys=True))))
 # Label-blind normalized/near-duplicate connected components across both sources.
 from sklearn.metrics.pairwise import cosine_similarity
 normalized=[norm(c['text']) for c in candidates]
 mat=TfidfVectorizer(ngram_range=(1,2),min_df=1).fit_transform(normalized)
 sim=cosine_similarity(mat)
 parent=list(range(len(candidates)))
 def find(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 def union(a,b):
  a,b=find(a),find(b)
  if a!=b:parent[max(a,b)]=min(a,b)
 exact={}
 for i,n in enumerate(normalized):
  if n in exact:union(i,exact[n])
  else:exact[n]=i
 for i,j in zip(*np.where(np.triu(sim,k=1)>=0.90)):union(int(i),int(j))
 components={}
 for i,c in enumerate(candidates):components.setdefault(find(i),[]).append(c)
 chosen=[];counts={0:0,1:0}
 for group in sorted(components.values(),key=lambda g:min(sha(c['text']) for c in g)):
  if len({c['label'] for c in group})>1:continue
  c=min(group,key=lambda c:sha(c['text']));label=c['label']
  if counts[label]>=N_PER_CLASS:continue
  c=dict(c,group='proxy-'+min(sha(norm(z['text'])) for z in group)[:16]);chosen.append(c);counts[label]+=1
 assert counts=={0:N_PER_CLASS,1:N_PER_CLASS},counts
 rows=[]
 for c in sorted(chosen,key=lambda c:sha(c['text'])):
  rows.append(dict(id='public-'+sha(c['text'])[:16],split='public_holdout',provenance='public_source_labeled',email_text=c['text'],phishing_label=c['label'],source=c['source'],source_record_index=c['source_row'],source_url=mbox_url if c['label'] else enron_url,source_label=c['source_label'],source_record_sha256=c['raw_sha256'],template_group_id=c['group'],campaign_id=None,realism='historical_public_email',annotation_basis='Source corpus label only; no independent expert adjudication.',endpoint_state=None,correlated_compromise=None,response_label=None,entities=None,transformations='MIME text extraction where applicable; HTML stripped retaining anchor targets; selected header lines/emails/numbers redacted; URL schemes defanged; whitespace normalized.'))
 assert len({r['email_text'] for r in rows})==100
 assert len({r['template_group_id'] for r in rows})==100
 syn_norm={norm(r['email_text']) for r in synth}
 assert not syn_norm.intersection(norm(r['email_text']) for r in rows)
 (ROOT/'augmented_dataset.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in synth+rows))
 writecsv(ROOT/'public_emails.csv',rows)
 (ROOT/'public_records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 train=[r for r in synth if r['split']=='train'];X=[r['email_text'] for r in train];y=[r['phishing_label'] for r in train]
 models={'tfidf_word_logreg':make_pipeline(TfidfVectorizer(ngram_range=(1,2),min_df=2),LogisticRegression(C=2,random_state=SEED,max_iter=1000)), 'tfidf_char_logreg':make_pipeline(TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2),LogisticRegression(C=2,random_state=SEED,max_iter=1000))}
 for m in models.values():m.fit(X,y)
 results=[];predictions=[]
 rule=re.compile(r'password|urgent|disable|verification code|gift card|unsigned|recovery code|executable',re.I)
 for split,sub in [('synthetic_test',[r for r in synth if r['split']=='test']),('public_holdout',rows)]:
  labels=[r['phishing_label'] for r in sub]
  for name in ['constant_benign','keyword_rule',*models]:
   p=[0]*len(sub) if name=='constant_benign' else ([int(bool(rule.search(r['email_text']))) for r in sub] if name=='keyword_rule' else models[name].predict([r['email_text'] for r in sub]))
   results.append(dict(split=split,baseline=name,**scores(labels,p)))
   for r,z in zip(sub,p):predictions.append(dict(id=r['id'],split=split,baseline=name,gold=r['phishing_label'],prediction=int(z)))
 writecsv(ROOT/'baseline_scores.csv',results);writecsv(ROOT/'predictions.csv',predictions)
 manifest.update(nazario_conservative_exclusions=NAZARIO_EXCLUSIONS,source_class_confound=True,candidate_counts={s:sum(c['source']==s for c in candidates) for s in ['Nazario_2021','Enron_curated_label0']},candidate_components=len(components),selected_counts=counts,synthetic_input_sha256=sha(SYN.read_bytes()),transformations=rows[0]['transformations'],scope='Public holdout only; source is confounded with class; no known campaign IDs or response/entity truth.',synthetic_overlap_check='No normalized exact matches against the 1000 synthetic records; not a semantic overlap guarantee.')
 (ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(dict(manifest=manifest,scores=results),indent=2))

if __name__=='__main__':main()
