#!/usr/bin/env python3
"""Create a small public HotpotQA development add-on; no model/answer generation.
Python >=3.10; requests, numpy, scikit-learn. Dataset adaptation: CC BY-SA 4.0.
python3 add_hotpotqa.py --out . --n 100
Offline: python3 add_hotpotqa.py --out rerun --source-json hotpotqa_source_sample.json
"""
import argparse,codecs,collections,csv,hashlib,json,math,random,re
from pathlib import Path
import requests
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

URL='https://huggingface.co/datasets/namlh2004/hotpotqa/resolve/7e54db4656209750ff487f6fdf8e39a66dba136b/hotpot_dev_distractor_v1.json'
LICENSE='https://creativecommons.org/licenses/by-sa/4.0/'
AUTHORS='Zhilin Yang, Peng Qi, Saizheng Zhang, Yoshua Bengio, William W. Cohen, Ruslan Salakhutdinov, Christopher D. Manning'
def js(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def jl(p,rows):p.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in rows))
def fetch(n):
    # Stream only the prefix needed, instead of downloading the 61 MB file.
    rows=[];buf='';dec=json.JSONDecoder();utf=codecs.getincrementaldecoder('utf-8')();read=0;started=False
    with requests.get(URL+'?download=true',stream=True,timeout=(20,60)) as r:
        r.raise_for_status()
        for block in r.iter_content(65536):
            read+=len(block)
            if read>8*1024*1024:raise RuntimeError('Prefix cap exceeded; reduce --n or use --source-json.')
            buf+=utf.decode(block)
            if not started:
                buf=buf.lstrip()
                if not buf:continue
                if not buf.startswith('['):raise ValueError('Expected upstream JSON array')
                buf=buf[1:];started=True
            while True:
                buf=buf.lstrip(' \r\n\t,')
                if not buf or buf[0]==']':break
                try:item,end=dec.raw_decode(buf)
                except json.JSONDecodeError:break
                rows.append(item);buf=buf[end:]
                if len(rows)==n:return rows,read
    raise RuntimeError(f'Only recovered {len(rows)} records; requested {n}')
def tok(s):return re.findall(r'[a-z0-9]+',s.lower())
def bm25(q,texts):
    bags=[collections.Counter(tok(t)) for t in texts];n=len(bags);df=collections.Counter(t for b in bags for t in b);avg=sum(sum(b.values()) for b in bags)/n
    scores=[]
    for b in bags:
        dl=sum(b.values());s=0
        for t in set(tok(q)):
            f=b[t];s+=math.log(1+(n-df[t]+.5)/(df[t]+.5))*f*2.5/(f+1.5*(.25+.75*dl/avg))
        scores.append(s)
    return sorted(range(n),key=lambda i:(-scores[i],i))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).parent);ap.add_argument('--n',type=int,default=100);ap.add_argument('--source-json',type=Path);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    if not 1<=a.n<=500:raise ValueError('Use 1 <= n <= 500 for this prefix-sampling tool')
    if a.source_json:
        source=json.loads(a.source_json.read_text())[:a.n];read=None
        if len(source)!=a.n:raise ValueError('Local source sample too small')
    else:source,read=fetch(a.n)
    js(a.out/'hotpotqa_source_sample.json',source)
    episodes=[]
    for index,r in enumerate(source):
        assert 1<=len(r['context'])<=10
        titles=[x[0] for x in r['context']];assert len(titles)==len(set(titles))
        memory=[{'id':f'p{i:02d}','title':title,'text':''.join(sents),'sentences':sents,'source':'wikipedia'} for i,(title,sents) in enumerate(r['context'])]
        titleids={d['title']:d['id'] for d in memory};supports=[]
        for title,sent in r['supporting_facts']:
            assert title in titleids and isinstance(sent,int) and 0<=sent<len(memory[titles.index(title)]['sentences'])
            supports.append({'document_id':titleids[title],'title':title,'sentence_index':sent})
        goldids=list(dict.fromkeys(s['document_id'] for s in supports));assert goldids
        episodes.append({'id':r['_id'],'split':'dev','scenario':'hotpotqa_'+r['type'],'query':r['question'],'local_context':'','memory':memory,
          'labels':{'answer':r['answer'],'answerable':True,'retrieval_required':True,'acceptable_evidence_sets':[goldids],'supporting_facts':supports,'question_type':r['type'],'difficulty':r['level']},
          'provenance':{'dataset':'HotpotQA','upstream_split':'dev_distractor','source_id':r['_id'],'source_index':index,'source_url':URL,'license':LICENSE,'adaptation_version':'1.0'}})
    assert len({r['id'] for r in episodes})==len(episodes)
    jl(a.out/'hotpotqa_episodes.jsonl',episodes)
    predictions=[]
    for row in episodes:
        # Only query, local_context and memory are used to produce rankings.
        docs=row['memory'];texts=[d['title']+' '+d['text'] for d in docs]
        vec=TfidfVectorizer();mat=vec.fit_transform(texts);scores=(mat@vec.transform([row['query']]).T).toarray().ravel()
        rnd=list(range(len(docs)));random.Random('6821299:'+row['id']).shuffle(rnd)
        rankings={'context_order':list(range(len(docs))),'seeded_random':rnd,'bm25':bm25(row['query'],texts),'tfidf':list(np.argsort(-scores,kind='stable'))}
        gold=set(row['labels']['acceptable_evidence_sets'][0]);sf=row['labels']['supporting_facts']
        for method,order in rankings.items():
            for k in [2,5]:
                ids=[docs[int(i)]['id'] for i in order[:k]];got=set(ids)
                predictions.append({'id':row['id'],'question_type':row['labels']['question_type'],'method':method,'k':k,'retrieved_ids':ids,
                  'paragraph_recall':len(gold&got)/len(gold),'complete_support':int(gold<=got),
                  'support_sentence_availability':sum(s['document_id'] in got for s in sf)/len(sf)})
    jl(a.out/'retrieval_predictions.jsonl',predictions)
    summary=[]
    for stratum in ['ALL','bridge','comparison']:
        for method in rankings:
            for k in [2,5]:
                p=[r for r in predictions if r['method']==method and r['k']==k and (stratum=='ALL' or r['question_type']==stratum)]
                if not p:continue
                summary.append({'stratum':stratum,'method':method,'k':k,'n':len(p),**{field:sum(r[field] for r in p)/len(p) for field in ['paragraph_recall','complete_support','support_sentence_availability']}})
    with (a.out/'retrieval_scores.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    st={'type':'string'};doc={'type':'object','additionalProperties':False,'required':['id','title','text','sentences','source'],'properties':{'id':st,'title':st,'text':st,'sentences':{'type':'array','items':st},'source':{'const':'wikipedia'}}}
    sf={'type':'object','additionalProperties':False,'required':['document_id','title','sentence_index'],'properties':{'document_id':st,'title':st,'sentence_index':{'type':'integer','minimum':0}}}
    props={'id':st,'split':{'const':'dev'},'scenario':{'enum':['hotpotqa_bridge','hotpotqa_comparison']},'query':st,'local_context':{'const':''},'memory':{'type':'array','minItems':1,'maxItems':10,'items':doc},
     'labels':{'type':'object','additionalProperties':False,'required':['answer','answerable','retrieval_required','acceptable_evidence_sets','supporting_facts','question_type','difficulty'],'properties':{'answer':st,'answerable':{'const':True},'retrieval_required':{'const':True},'acceptable_evidence_sets':{'type':'array','minItems':1,'maxItems':1,'items':{'type':'array','minItems':1,'uniqueItems':True,'items':st}},'supporting_facts':{'type':'array','minItems':1,'items':sf},'question_type':{'enum':['bridge','comparison']},'difficulty':{'enum':['easy','medium','hard']}}},
     'provenance':{'type':'object','additionalProperties':False,'required':['dataset','upstream_split','source_id','source_index','source_url','license','adaptation_version'],'properties':{'dataset':{'const':'HotpotQA'},'upstream_split':{'const':'dev_distractor'},'source_id':st,'source_index':{'type':'integer','minimum':0},'source_url':{'const':URL},'license':{'const':LICENSE},'adaptation_version':{'const':'1.0'}}}}
    js(a.out/'hotpotqa_schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','title':'HotpotQA native retrieval add-on v1','type':'object','additionalProperties':False,'required':list(props),'properties':props})
    # Human-readable preview; gold evidence is evaluation-only.
    preview=['# Public HotpotQA examples','', f'The first {min(5,len(episodes))} of {len(episodes)} development examples. Gold answers and evidence below are evaluator-only.','']
    for row in episodes[:5]:
        preview+=['## '+row['id'],row['query'],'','**Gold answer:** '+row['labels']['answer'],'']
        for s in row['labels']['supporting_facts']:
            d=next(d for d in row['memory'] if d['id']==s['document_id'])
            preview+=['- '+s['title']+' [sentence '+str(s['sentence_index'])+']: '+d['sentences'][s['sentence_index']]]
        preview+=['']
    preview+=['Adapted from HotpotQA, Yang et al. (2018), '+LICENSE+'. Source: '+URL]
    (a.out/'EXAMPLES.md').write_text('\n'.join(preview)+'\n')
    js(a.out/'provenance_and_validation.json',{'dataset':'HotpotQA','authors':AUTHORS,'official_site':'https://hotpotqa.github.io/','official_source':'http://curtis.ml.cmu.edu/datasets/hotpot/hotpot_dev_distractor_v1.json',
      'download_url':URL,'mirror_revision':'7e54db4656209750ff487f6fdf8e39a66dba136b','mirror_note':'Third-party mirror; byte identity to unavailable official download not verified. Official schema and license verified.','license':LICENSE,
      'sampling':'First n complete records in source array, without label-based filtering; nonrandom convenience sample','n':len(episodes),'bytes_streamed':read,
      'question_type_counts':dict(collections.Counter(r['labels']['question_type'] for r in episodes)),'difficulty_counts':dict(collections.Counter(r['labels']['difficulty'] for r in episodes)),
      'context_size_counts':dict(collections.Counter(len(r['memory']) for r in episodes)),'paragraphs':sum(len(r['memory']) for r in episodes),'support_facts':sum(len(r['labels']['supporting_facts']) for r in episodes),'status':'passed',
      'checks':['unique question IDs','1-10 distinct-title paragraphs per example; source context sizes preserved','every supporting title resolves','every zero-based sentence index is in range','answer and source sentence text preserved','no gold labels used in retrieval rankings'],
      'sha256':{name:hashlib.sha256((a.out/name).read_bytes()).hexdigest() for name in ['hotpotqa_source_sample.json','hotpotqa_episodes.jsonl','hotpotqa_schema.json','retrieval_scores.csv']}})
    print(json.dumps({'counts':collections.Counter(r['labels']['question_type'] for r in episodes),'overall_scores':[r for r in summary if r['stratum']=='ALL']},indent=2))
if __name__=='__main__':main()
