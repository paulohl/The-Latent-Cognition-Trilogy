#!/usr/bin/env python3
"""Authored paired hard negatives; unchanged synthetic training; no heavy models.
Run beside base_dataset.jsonl, base_schema.json and scenarios.json.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import csv,hashlib,json,re,platform
from pathlib import Path
import numpy as np
import sklearn
from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,accuracy_score,precision_score,recall_score,f1_score

ROOT=Path(__file__).resolve().parent
SEED=172289201

def sha(s):return hashlib.sha256(s if isinstance(s,bytes) else s.encode()).hexdigest()
def norm(s):return ' '.join(re.findall('[a-z]+',re.sub(r'\d+',' N ',s.lower())))
def writecsv(name,rows):
 with (ROOT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def summarize(y,p):
 tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
 return dict(n=len(y),accuracy=float(accuracy_score(y,p)),precision=float(precision_score(y,p,zero_division=0)),recall=float(recall_score(y,p,zero_division=0)),f1=float(f1_score(y,p,zero_division=0)),false_positive_rate=float(fp/(tn+fp)),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp))

def main():
 base=[json.loads(l) for l in (ROOT/'base_dataset.jsonl').read_text().splitlines()]
 assert len(base)==1100
 assert {s:sum(r['split']==s for r in base) for s in ['train','validation','test','public_holdout']}=={'train':800,'validation':100,'test':100,'public_holdout':100}
 specs=json.loads((ROOT/'scenarios.json').read_text());rows=[]
 assert len(specs)==20
 for spec in specs:
  for variant,(benign,malicious) in enumerate(spec['variants']):
   pair=spec['family']+'-'+str(variant)
   for label,body in enumerate([benign,malicious]):
    text='Subject: '+spec['subject']+'\n'+body
    rows.append(dict(id='hn-'+sha(text)[:16],split='hard_negative_challenge',provenance='authored_synthetic_hard_negative_v1',email_text=text,phishing_label=label,family_id=spec['family'],pair_id=pair,wording_variant=variant,lexical_cue=spec['cue'],negative_rationale=spec['rationale'],annotation_basis='Authored scenario intent and requested action; not independently adjudicated.',endpoint_state=None,correlated_compromise=None,response_label=None,entities=None,campaign_id=None))
 assert len(rows)==80 and sum(r['phishing_label']==0 for r in rows)==40
 assert len({r['email_text'] for r in rows})==len(rows)
 assert not {norm(r['email_text']) for r in rows}&{norm(r['email_text']) for r in base}
 pairs={}
 for r in rows:pairs.setdefault(r['pair_id'],[]).append(r)
 assert len(pairs)==40 and all({r['phishing_label'] for r in pair}=={0,1} for pair in pairs.values())
 (ROOT/'challenge.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 writecsv('hard_negatives.csv',[r for r in rows if r['phishing_label']==0])
 (ROOT/'augmented_dataset_v3.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in base+rows))
 train=[r for r in base if r['split']=='train'];assert len(train)==800
 models={
  'tfidf_word_logreg':make_pipeline(TfidfVectorizer(ngram_range=(1,2),min_df=2),LogisticRegression(C=2,random_state=SEED,max_iter=1000)),
  'tfidf_char_logreg':make_pipeline(TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2),LogisticRegression(C=2,random_state=SEED,max_iter=1000))}
 for model in models.values():model.fit([r['email_text'] for r in train],[r['phishing_label'] for r in train])
 keyword=re.compile(r'password|urgent|disable|verification code|gift card|unsigned|recovery code|executable',re.I)
 results=[];predictions=[];families=[]
 for split,subset in [('synthetic_test',[r for r in base if r['split']=='test']),('public_holdout',[r for r in base if r['split']=='public_holdout']),('hard_negative_challenge',rows)]:
  y=[r['phishing_label'] for r in subset]
  for name in ['constant_benign','keyword_rule',*models]:
   pred=[0]*len(subset) if name=='constant_benign' else ([int(bool(keyword.search(r['email_text']))) for r in subset] if name=='keyword_rule' else models[name].predict([r['email_text'] for r in subset]))
   lookup={r['id']:int(p) for r,p in zip(subset,pred)}
   pair_accuracy=sum(all(lookup[r['id']]==r['phishing_label'] for r in pair) for pair in pairs.values())/len(pairs) if split=='hard_negative_challenge' else None
   results.append(dict(split=split,baseline=name,**summarize(y,pred),both_members_correct_rate=pair_accuracy))
   for r,p in zip(subset,pred):predictions.append(dict(id=r['id'],split=split,baseline=name,gold=r['phishing_label'],prediction=int(p)))
   if split=='hard_negative_challenge':
    for family in [s['family'] for s in specs]:
     rr=[r for r in rows if r['family_id']==family];pp=[lookup[r['id']] for r in rr]
     families.append(dict(family_id=family,baseline=name,**summarize([r['phishing_label'] for r in rr],pp),both_members_correct_rate=sum(all(lookup[r['id']]==r['phishing_label'] for r in pair) for pair in pairs.values() if pair[0]['family_id']==family)/2))
 writecsv('baseline_scores.csv',results);writecsv('predictions.csv',predictions);writecsv('family_scores.csv',families)
 # Extend, rather than weaken, the existing schema. Old rows retain old contracts.
 schema=json.loads((ROOT/'base_schema.json').read_text())
 sample=rows[0];props={}
 for k,v in sample.items():props[k]={'type':'null' if v is None else ('integer' if type(v)==int else 'string')}
 props['split']={'const':'hard_negative_challenge'};props['provenance']={'const':'authored_synthetic_hard_negative_v1'};props['phishing_label']={'type':'integer','enum':[0,1]}
 props['email_text']['description']='Only permitted model feature. Every other field is gold annotation or metadata.'
 props['negative_rationale']['description']='Gold explanation attached to both members of the pair; never a feature.'
 props['family_id']['description']='Authored scenario topic, not a verified real-world campaign.'
 for k in ['endpoint_state','correlated_compromise','response_label','entities','campaign_id']:props[k]['description']='Unknown/not annotated. Null is not benign, no action, or an empty set.'
 schema['$defs']['hard_negative']={'type':'object','additionalProperties':False,'required':list(sample),'properties':props}
 schema['oneOf'].append({'$ref':'#/$defs/hard_negative'});schema['title']='PhishIR v3: synthetic + public + authored hard-negative challenge'
 (ROOT/'schema.json').write_text(json.dumps(schema,indent=2)+'\n')
 manifest=dict(seed=SEED,source='Authored scenarios; no new public emails or external model generation.',base_input_sha256=sha((ROOT/'base_dataset.jsonl').read_bytes()),scenario_spec_sha256=sha((ROOT/'scenarios.json').read_bytes()),challenge_sha256=sha((ROOT/'challenge.jsonl').read_bytes()),n_challenge=80,n_hard_negatives=40,n_positive_controls=40,n_scenario_families=20,n_matched_pairs=40,n_combined=1180,train_rows=800,validation='Pair labels, full-text uniqueness, no normalized exact overlap with old data, original training count.',versions=dict(python=platform.python_version(),numpy=np.__version__,sklearn=sklearn.__version__),distilbert_status='Not run; no transformer scores claimed.',limitations='Authored development cases; two paraphrases per family, no verified campaigns, explanations may make authorization explicit; new templates not all semantically disjoint from original lure topics.')
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(results,indent=2))

if __name__=='__main__':main()
